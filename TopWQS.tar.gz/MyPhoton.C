/*
 * MyPhoton.cpp
 *
 *  Created on: Feb 1, 2012
 *      Author: csander
 */

#include "MyPhoton.h"

MyPhoton::MyPhoton() {
   // TODO Auto-generated constructor stub
}

MyPhoton::~MyPhoton() {
   // TODO Auto-generated destructor stub
}
