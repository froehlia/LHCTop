/*
 * MyElectron.cpp
 *
 *  Created on: Feb 1, 2012
 *      Author: csander
 */

#include "MyElectron.h"

MyElectron::MyElectron() {
   // TODO Auto-generated constructor stub
}

MyElectron::~MyElectron() {
   // TODO Auto-generated destructor stub
}
